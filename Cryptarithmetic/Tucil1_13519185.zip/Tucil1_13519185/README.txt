----------------------------------------------------------
Tugas Kecil 1 IF2211 Strategi Algoritma 2020/2021
Penyelesaian Cryptarithmetic dengan Algoritma Brute Force

		Richard Rivaldo - 13519185
----------------------------------------------------------

* Program Cryptarithmetic.py adalah program yang dibuat
  untuk menyelesaikan permasalahan puzzle Cryptarithmetic,
  yaitu memecahkan operasi penjumlahan huruf dengan prinsip
  substitusi sebuah huruf tepat dengan satu buah angka dan
  huruf pertama setiap kata tidak boleh diawali dengan 0.

* Program dibuat dengan menggunakan bahasa pemrograman Python.
  Tidak ada requirement tertentu untuk menjalankan program.

* Program disarankan untuk dijalankan secara langsung melalui
  penggunaan In-Built Terminal sebuah IDE karena pemanggilan
  prosedur di dalam program didesain untuk dieksekusi atau 
  dirun langsung di dalam IDE. 

* Jika dijalankan melalui terminal luar, maka pemanggilan prosedur 
  yang telah dituliskan di dalam program harus dihapus terlebih 
  dahulu. Lalu, melalui terminal, pindah ke dalam direktori yang
  berisi Source Code Program dan File input, lalu tuliskan perintah

  python Cryptarithmetic.py cryptarithmetic("<filename.txt>")

  dengan mengganti <filename.txt> menjadi nama input file.

* Program hanya memerlukan nama file yang menjadi input persoalan
  yang ingin dipecahkan. Perlu diperhatikan, file ini harus berada
  di dalam direktori yang sama dengan source code program.